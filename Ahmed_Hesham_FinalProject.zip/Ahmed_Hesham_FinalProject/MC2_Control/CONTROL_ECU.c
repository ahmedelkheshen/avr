/******************************************************************************
 *
 * Module: CONTROL APP
 *
 * File Name: CONTROL_ECU.c
 *
 * Description: Source file for the CONTROL APP Layer
 *
 * Author: Ahmed Hesham
 *
 *******************************************************************************/


#include <avr/io.h>
#include <util/delay.h>
#include "std_types.h"
#include "external_eeprom.h"
#include "timer.h"
#include "twi.h"
#include "dc_motor.h"
#include "buzzer.h"
#include "uart.h"


#define PASSWORD_CHAR 5
#define PASSWORD_ADDRESS 0x00FF

uint8 g_tick=0;
uint8 g_flag=0;
uint8 Checked=0;

typedef enum{
	RIGHT,WRONG
}STATUS;

/*******************************************************************************
 *                      Functions Prototypes                                   *
 *******************************************************************************/

void PasswordSave(void);
void DoorOpen(void);
void PasswordChange(void);
void MotorDoor(void);
void Alert(void);
void Buzzer(void);

/*******************************************************************************
 *                     				Main 	                                   *
 *******************************************************************************/


int main(void)
{
	SREG   |= (1<<7);
	DcMotor_Init();

	Buzzer_init();

	TWI_ConfigType twiConfig={0b00000010,400000};
	TWI_init(&twiConfig);

	UART_ConfigType uartConfig={BIT_DATA_8,DISABLED,ONE_BIT,9600};
	UART_init(&uartConfig);

	PasswordSave();

	for(;;)
	{
		if(UART_recieveByte()=='+')
		{
			DoorOpen();
		}
		else if(UART_recieveByte()=='-')
		{
			PasswordChange();
		}
	}



}

/*******************************************************************************
 *                      Functions Definitions                                  *
 *******************************************************************************/

void PasswordSave(void)
{
	uint8 arr[5]={0};
	STATUS State=RIGHT;
	for(int i=0;i<PASSWORD_CHAR;i++)
	{
		arr[i]=UART_recieveByte();
	}
	for(int i=0;i<PASSWORD_CHAR;i++)
	{
		if(arr[i]!=UART_recieveByte())
		{
			State=WRONG;
		}
	}
	UART_sendByte(State);
	if(State==WRONG)
	{
		PasswordSave();
	}
	else
	{
		for(int i=0;i<PASSWORD_CHAR;i++)
		{
			_delay_ms(10);
			EEPROM_writeByte(PASSWORD_ADDRESS+i,arr[i]);
		}
	}
}

void Buzzer(void)
{
	g_tick++;
	Buzzer_on();
	if(g_tick==120)
	{
		Buzzer_off();
		g_tick=0;
		Timer1_deInit();
	}

}


void DoorOpen(void)
{
	uint8 read;
	STATUS State=RIGHT;
	for(int i=0;i<PASSWORD_CHAR;i++) //check if password is correct
	{
		_delay_ms(10);
		EEPROM_readByte(PASSWORD_ADDRESS+i, &read);
		if(read!=UART_recieveByte())
		{
			State=WRONG;
		}
	}

	UART_sendByte(State); //send STATE to other MC

	if(State==RIGHT) //success & open door
	{
		Checked=0;

		Timer1_setCallBack(MotorDoor);
		Timer1_ConfigType t1Config={0,0,PS_64_T1,NORM_T1,NONE,TOGGLE_T1};
		Timer1_init(&t1Config);
	}
	else if(State==WRONG) //failure
	{
		Checked++;
		if(Checked==3) //send error if counter = 3
		{
			Checked=0;
			Alert();
		}
		else
		{
			DoorOpen(); //repeat as long as counter less than 3
		}
	}
}
void PasswordChange(void)
{
	uint8 read;
	STATUS State=RIGHT;

	for(int i=0;i<PASSWORD_CHAR;i++)
	{
		_delay_ms(10);
		EEPROM_readByte(PASSWORD_ADDRESS+i, &read);

		if(read!=UART_recieveByte())
		{
			State=WRONG;
		}
	}
	UART_sendByte(State);
	if(State==RIGHT)
	{
		Checked=0;
		PasswordSave();
	}
	else
	{
		Checked++;
		if(Checked==3)
		{
			Checked=0;
			Alert();
		}
		else
		{
			PasswordChange();
		}

	}
}

void MotorDoor(void)
{
	g_tick++;
	if(g_tick==66)
	{
		DcMotor_Rotate(NO_ROTATION,100);
		Timer1_deInit();
		g_tick=0;
	}
	else if(g_tick<30)
	{
		DcMotor_Rotate(CW_ROTATION,100);
	}
	else if(g_tick<36)
	{
		DcMotor_Rotate(NO_ROTATION,100);
	}
	else
	{
		DcMotor_Rotate(CCW_ROTATION,100);
	}

}


void Alert(void)
{
	Timer1_setCallBack(Buzzer);
	Timer1_ConfigType t1Config={0,0,PS_64_T1,NONE,TOGGLE_T1};
	Timer1_init(&t1Config);
}


