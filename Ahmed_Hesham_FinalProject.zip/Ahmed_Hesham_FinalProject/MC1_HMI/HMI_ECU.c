/******************************************************************************
 *
 * Module: HMI APP
 *
 * File Name: HMI_ECU.c
 *
 * Description: Source file for the HMI APP Layer
 *
 * Author: Ahmed Hesham
 *******************************************************************************/

#include "keypad.h"
#include "lcd.h"
#include "uart.h"
#include "timer.h"
#include "std_types.h"
#include <util/delay.h>
#include <avr/io.h>

#define PASSWORD_CHAR 5

uint8 tick=0;
uint8 flag=0;
uint8 Checked=0;


/*******************************************************************************
 *                      Functions Prototypes                                   *
 *******************************************************************************/

void PasswordForm(void);
void Alert_callBack(void);
void Alert(void);
void DoorOpen_callBack(void);
void DoorOpen(void);
void PasswordRenew(void);


int main(void)
{

	SREG   |= (1<<7);
	LCD_init();

	UART_ConfigType uartConfig={BIT_DATA_8,DISABLED,ONE_BIT,9600};
	UART_init(&uartConfig);

	/*
	 * For initiation of pass
	 */
	PasswordForm();

	for(;;)
	{
		LCD_clearScreen();
		uint8 option;
		LCD_moveCursor(0,0);
		LCD_displayString("+ : Open Door");
		LCD_moveCursor(1,0);
		LCD_displayString("- : Change Pass");
		option=KEYPAD_getPressedKey();
		if(option=='+')
		{
			UART_sendByte('+');
			DoorOpen();
		}
		else if(option=='-')
		{
			UART_sendByte('-');
			PasswordRenew();
		}
	}
}

/*******************************************************************************
 *                  		      Functions                                    *
 *******************************************************************************/



void DoorOpen(void)
{
	LCD_clearScreen();
	LCD_moveCursor(0,0);
	LCD_displayString("Plz enter pass: ");
	LCD_moveCursor(1,0); //ask for password

	sint8 value;
	uint8 counter=0;
	do  //write password & wait until '=' is pressed
	{
		counter++;
		value=KEYPAD_getPressedKey();
		_delay_ms(250);
		if(counter<=PASSWORD_CHAR) //accept only 5 inputs to send & display
		{
			UART_sendByte(value);
			LCD_displayCharacter('*');
		}

	}while(value!='=');


	LCD_clearScreen();

	if(UART_recieveByte()) //error in password
	{
		Checked++;
		if(Checked==3) //check 3 times before sending error
		{
			Checked=0;
			Alert();
		}
		else
		{
			DoorOpen(); //repeat as long as counter less than 3
		}
	}
	else //success & set timer to open door
	{
		LCD_clearScreen();
		Checked=0;
		Timer1_setCallBack(DoorOpen_callBack);
		Timer1_ConfigType t1Config={0,0,PS_64_T1,NORM_T1,NONE,TOGGLE_T1};
		Timer1_init(&t1Config);
		while(flag==0);
		flag=0;
	}
}



void DoorOpen_callBack(void)
{
	tick++;
	if(tick==66)
	{
		LCD_clearScreen();
		LCD_moveCursor(0,0);
		LCD_displayString("LOCKED   ");
		Timer1_deInit();
		tick=0;
		flag=1;
	}
	else if(tick<30)
	{
		LCD_moveCursor(0,0);
		LCD_displayString("Door is    ");
		LCD_moveCursor(1,0);
		LCD_displayString("Unlocking    ");
	}
	else if(tick<66)
	{
		LCD_moveCursor(0,0);
		LCD_displayString("Door is   ");
		LCD_moveCursor(1,0);
		LCD_displayString("Locking    ");
	}



}

void PasswordForm(void)
{
	sint8 value=-1;
	LCD_displayString("Plz enter pass: ");
	LCD_moveCursor(1,0);

	uint8 counter=0;
	do
	{
		counter++;
		value=KEYPAD_getPressedKey();
		_delay_ms(250);
		if(counter<=PASSWORD_CHAR)
		{
			UART_sendByte(value);
			LCD_displayCharacter('*');
		}

	}while(value!='=');
	LCD_clearScreen();
	LCD_moveCursor(0,0);
	LCD_displayString("Plz re-enter the");
	LCD_moveCursor(1,0);
	LCD_displayString("same pass: ");

	counter=0;
	do
	{
		counter++;
		value=KEYPAD_getPressedKey();
		_delay_ms(250);
		if(counter<=PASSWORD_CHAR)
		{
			UART_sendByte(value);
			LCD_displayCharacter('*');
		}

	}while(value!='=');
	LCD_clearScreen();
	if(UART_recieveByte())
	{
		PasswordForm();
	}
	else
	{
		return;
	}
}


void PasswordRenew(void)
{
	UART_sendByte('-');
	LCD_clearScreen();
	LCD_moveCursor(0,0);
	LCD_displayString("Plz enter pass: ");
	LCD_moveCursor(1,0);

	sint8 value;
	uint8 counter=0;
	do
	{
		counter++;
		value=KEYPAD_getPressedKey();
		_delay_ms(250);
		if(counter<=5)
		{
			UART_sendByte(value);
			LCD_displayCharacter('*');
		}

	}while(value!='=');
	LCD_clearScreen();
	if(UART_recieveByte())
	{
		Checked++;
		if(Checked==3)
		{
			Checked=0;
			Alert();
		}
		else
		{
			PasswordRenew();
		}
	}
	else
	{
		Checked=0;
		PasswordForm();
	}
}



void Alert(void)
{
	Timer1_setCallBack(Alert_callBack);
	Timer1_ConfigType t1Config={0,0,PS_64_T1,NONE,TOGGLE_T1};
	Timer1_init(&t1Config);

	LCD_clearScreen();
	LCD_moveCursor(0,0);
	LCD_displayString("ALERT");

	while(flag==0);
	flag=0;


}

void Alert_callBack(void)
{
	tick++;
	if(tick==120)
	{
		flag=1;
		Timer1_deInit();
		tick=0;
	}
}
