/**
 * project c
 * date:11/3/2023
 * author: Ahmed Hesham Mohamed
 */

#include<stdio.h>
#include<math.h>
#include"types.h"

//**************************** function prototype ********************************//

void first_menu(void); /* function to have the menu of turning the engine off
								or on and quit the program*/

void choose_FirstMenu(uint8 x);// function to choose what option i want

void choose_TurnOnMenu(uint8 x);// function to choose what option i want

void turn_on_menu(void); /* function to have the menu of turning the engine off,
 	 	 	 	 	 	 	traffic light, room temp, engine temp*/

void set_RoomTemp(void);/*function to write the room temp and shows the
                          properties of the car if the AC or ETC is on or off
                           and the reading of the sensors */

void set_EngineTemp(void);/*function to write the engine temp and shows the
                           properties of the car if the AC or ETC is on or off
                           and the reading of the sensors */

void set_TrafficLight(void);/*function to write the traffic light and shows the
							properties of the car if the AC or ETC is on or off
							 and the reading of the sensors */
void display1(void); /* function to display the on the screen the sensors read of
 	 	 	 	 	 	normal condition */

void display2(void); /* function to display the on the screen the sensors read of
 	 	 	 	 	 	orange traffic light color condition */

//************************ Global variables *************************************//

void (*ptr[5])(void)={first_menu,
		turn_on_menu,
		set_TrafficLight,
		set_RoomTemp,
		set_EngineTemp};/* this is array of pointers and these pointers are pointers
		                   to function for the function that don't have call*/

void (*choose[2])(uint8)={choose_FirstMenu, choose_TurnOnMenu};/* this is array of
pointers and these pointers are pointers to function for the function that
have call*/

typedef struct
{
	float32 speed; // defining the speed of the car as decimal number
	float32 room_temp; // defining the room temperature of the car as decimal number
	float32 engine_temp; // defining the engine temperature of the car as decimal number
}car; // used typedef instead of using struct car every time
car x; // structure of the car readings

int main(void)
{
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
	printf("speed = ");
	scanf(" %f",&x.speed); // writing the initial value of the speed
	printf("room temperature = ");
	scanf(" %f",&x.room_temp);// writing the initial value of the room temperature
	printf("engine temperature = ");
	scanf(" %f",&x.engine_temp);// writing the initial value of the engine temperature
	ptr[0](); // calling first_menu function
	printf("Quit the system\n");
	return 0;
}
void first_menu(void)
{
	printf("a. Turn on the vehicle engine\n");
	printf("b. Turn off the vehicle engine\n");
	printf("c. Quit the system\n\n");
	uint8 i; /* Initialization for local variable called i in the main that
	            only can be used in that function */
	scanf(" %c",&i); // to the choose the option that i want
	choose[0](i);// calling choose_firstMenu function
}
void choose_FirstMenu(uint8 x)// x was called by value of the char i
{
	switch(x)
	{
	case 'a':
		ptr[1](); // calling turn on menu function
		break;
	case 'b':
		ptr[0]();// calling first_menu function
		break;
	case 'c':/* in this case it will return to main as all functions is finished
	and the code while be finished*/
		break;
	}
}
void turn_on_menu(void)
{
	printf("a. Turn off the engine\n");
	printf("b. Set the traffic light color\n");
	printf("c. Set the room temperature (Temperature Sensor)\n");
	printf("d. Set the engine temperature (Engine Temperature Sensor)\n\n");
	uint8 i;/* Initialization for local variable called i in the turn on menu that
	            only can be used in that function */
	scanf(" %c",&i); // to the choose the option that i want
	(choose[1])(i); // calling choose_TurnOnMenu function
}
void choose_TurnOnMenu(uint8 x)
{
	switch(x)
	{
	case 'a':
		ptr[0](); // calling first menu function
		break;
	case 'b':
		ptr[2]();// calling traffic light function
		break;
	case 'c':
		ptr[3]();// calling room temperature function
		break;
	case 'd':
		ptr[4](); // calling engine temperature function
		break;
	}
}
void set_TrafficLight(void)
{
	printf("enter the required color:\n");
	uint8 i;/* Initialization for local variable called i in the traffic light set
			that only can be used in that function */
	scanf(" %c", &i);// put the traffic light color
	switch(i)// condition function of the color
	{
	case('g'): // if i was equal g
	x.speed = 100.0; // making speed in the structure = 100
	display1(); // calling
	break;
	case('o'):
	x.speed = 30.0;
	display2(); // calling
	break;
	case('r'):
	x.speed = 0;
	display1(); // calling
	break;
	}
	ptr[1]();
}
void set_RoomTemp(void)
{
	printf("enter the required room temperature:\n");
	scanf(" %f",&x.room_temp);
	display1();
	ptr[1]();

}
void set_EngineTemp(void)
{
	printf("enter the required engine temperature:\n");
	scanf(" %f",&x.engine_temp);
	display1();
	ptr[1]();

}
void display1(void)
{
	printf("engine is ON\n");
	if(x.room_temp >= 10 && x.room_temp <= 30) // condition
	{

		printf("AC is OFF\n");
	}
	else
	{

		printf("AC is ON\n");
		x.room_temp = 20.0; // making room temp in the structure = 100
	}
	printf("vehicle speed: %f km/hr\n", x.speed);
	printf("Room Temperature: %f\n", x.room_temp);
	if(x.engine_temp >= 100.0 && x.engine_temp <= 150.0) // condition
	{

		printf("Engine Temperature Controller is OFF\n");
		printf("engine temperature: %f\n",x.engine_temp);
	}
	else
	{

		printf("Engine Temperature Controller is ON\n");
		x.engine_temp = 125.0; // making engine temp in the structure = 100
		printf("engine temperature: %f\n\n",x.engine_temp);
	}
}
void display2(void)
{
	printf("engine is ON\n");
	printf("AC is ON\n");
	x.room_temp = x.room_temp*(5.0/4.0) + 1;
	printf("vehicle speed: %f km/hr\n", x.speed);
	printf("Room Temperature: %f\n", x.room_temp);
	printf("Engine Temperature Controller is ON\n");
	x.engine_temp *= (5.0/4.0) + 1;
	printf("engine temperature: %f\n\n",x.engine_temp);
}
